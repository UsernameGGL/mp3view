class CanvasEnum {

}

export default CanvasEnum;