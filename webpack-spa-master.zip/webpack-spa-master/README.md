# 这是一个基于webpack构建的前端项目，使用我自己的思路进行组件化开发
#  计划完成： 路由匹配功能

#  已完成： 音乐可视化项目。即Canvas组件和Audio组件
完整readMe正由看云构建中：链接在下面

[音乐可视化](https://www.kancloud.cn/lei1142908626/webpack-spa/488820)