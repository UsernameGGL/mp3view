package com.manager.server.controller;

import com.manager.server.model.Weather;
import com.manager.server.service.DeleteWeather;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.sql.Date;

@Controller
@EnableAutoConfiguration
public class Delete {
    @Autowired
    private DeleteWeather delete;
    private final Logger logger = LoggerFactory.getLogger(Delete.class);

    @RequestMapping(value = "/delete")
    public String delete (Weather entity) {
        System.out.println("***controller.Delete*********************************");
        logger.info("\n\tCurrent manager is trying to delete weather information from DateBase. \n"
                + "\tHere is the content of weather: \n\t" + entity.toString());
        if (delete.deleteByTime(entity)) {
            logger.info("\n\tDelete weather successfully.\n");
            return "success";
        } else {
            logger.info("\n\tFailed to delete weather.\n");
            return "error";
        }
    }

    @RequestMapping(value = "/testDelete")
    public void select (){
        Weather entity = new Weather();
        entity.setTime(new Date(10,1,1));
        this.delete(entity);
    }
}
