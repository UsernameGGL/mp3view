package com.manager.server.controller;

import com.manager.server.model.Weather;
import com.manager.server.service.UpdateWeather;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.sql.Date;

@Controller
@EnableAutoConfiguration
public class Update {
    @Autowired
    private UpdateWeather update;
    private final Logger logger = LoggerFactory.getLogger(Update.class);

    @RequestMapping(value = "/update")
    public String update (@Valid Weather entity, BindingResult bindingResult){
        System.out.println("***controller.Update*********************************");
        logger.info("\n\tCurrent manager is trying to update weather information to DateBase. \n"
                + "\tHere is the content of weather: \n\t" + entity.toString());
        if (update.updateByTime(entity)){
            logger.info("\n\tUpdate weather successfully.\n");
            return "success";
        }
        else {
            logger.info("\n\tFailed to update weather.\n");
            return "fail";
        }
    }

    @RequestMapping(value = "/testUpdate")
    public void test() {
        Weather entity = new Weather();
        entity.setTime(new Date(10,1,1));
        entity.setHumidity(30);
        entity.setWeather(5);
        this.update(entity,null);
    }
}
