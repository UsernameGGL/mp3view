package com.manager.server.controller;

import com.manager.server.model.Weather;
import com.manager.server.service.InsertWeather;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.sql.Date;

@Controller
@EnableAutoConfiguration
public class Insert {
    @Autowired
    private InsertWeather insert;
    private final Logger logger = LoggerFactory.getLogger(Insert.class);

    @RequestMapping(value = "goInto")
    public String goInto(){
        return "insert";
    }

    @RequestMapping(value = "/insert")
    public String insert (Weather entity){
        System.out.println("***controller.Insert*********************************");
        logger.info("\n\tCurrent manager is trying to insert weather information to DateBase. \n"
                + "\tHere is the content of weather: \n\t" + entity.toString());
        if (insert.insertToTable(entity)){
            logger.info("\n\tInsert weather successfully.\n");
            return "success";
        }
        else {
            logger.info("\n\tFailed to insert weather.\n");
            return "error";
        }
    }

    @RequestMapping(value = "/testInsert")
    public void test(){
        Weather entity = new Weather();
        entity.setTime(new Date(10,1,1));
        entity.setHumidity(20);
        entity.setWeather(5);
        this.insert(entity);
    }
}
