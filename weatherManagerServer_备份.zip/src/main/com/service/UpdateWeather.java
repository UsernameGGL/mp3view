package service;

import dao.WeatherDao;
import entity.Weather;
import entity.WeatherEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UpdateWeather {
    @Autowired
    private WeatherDao weatherDao;

    public boolean updateWeather (Weather entity) {
        WeatherEntity weatherEntity = entity.convertToWeatherEntity();
        return weatherDao.updateWeather(weatherEntity);
    }
}
