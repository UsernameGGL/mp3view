package service;

import dao.WeatherDao;
import entity.Weather;
import entity.WeatherEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SelectWeather {
    @Autowired
    private WeatherDao weatherDao;

    public List<Weather> selectWeather (Weather start, Weather end) {
        List<Weather> list = null;
        List<WeatherEntity> listEntity = null;

        listEntity = weatherDao.selectByDateRange(start.convertToWeatherEntity(), end.convertToWeatherEntity());
        for (int i = 0; i < listEntity.size(); i++) {
            list.add(new Weather(listEntity.get(i)));
        }

        return list;
    }
}
