package service;

import dao.WeatherDao;
import entity.Weather;
import entity.WeatherEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DeleteWeather {
    @Autowired
    private WeatherDao weatherDao;

    public boolean deleteWeather (Weather entity) {
        WeatherEntity weatherEntity = entity.convertToWeatherEntity();
        return weatherDao.deleteByDate(weatherEntity);
    }
}
