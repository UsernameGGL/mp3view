package service;

import dao.WeatherDao;
import entity.Weather;
import entity.WeatherEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InsertWeather {
    @Autowired
    private WeatherDao weatherDao;

    public boolean insertWeather (Weather entity) {
        WeatherEntity weatherEntity = entity.convertToWeatherEntity();
        return weatherDao.insertInTable(weatherEntity);
    }
}
