package controller;

import entity.Weather;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import service.InsertWeather;

@Controller
public class Insert {
    @Autowired
    private InsertWeather insert;

    @RequestMapping(value = "/insert")
    public String insert(Weather entity, Model model) {
        model.addAttribute("entity", entity);
        if (insert.insertWeather(entity)) return "successInsert";
        else  return "fail";
    }
}
