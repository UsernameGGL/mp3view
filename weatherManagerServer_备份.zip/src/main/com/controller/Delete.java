package controller;

import entity.Weather;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import service.DeleteWeather;

@Controller
public class Delete {
    @Autowired
    private DeleteWeather delete;

    @RequestMapping(value = "/delete")
    public String delete(Weather entity, Model model) {
        model.addAttribute("entity", entity);
        if (delete.deleteWeather(entity)) return "successDelete";
        else  return "fail";
    }
}
