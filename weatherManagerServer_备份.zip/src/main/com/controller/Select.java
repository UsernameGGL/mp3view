package controller;

import entity.Weather;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import service.SelectWeather;

@Controller
public class Select {
    @Autowired
    private SelectWeather select;

    @RequestMapping(value = "/select")
    public String find(Weather start, Weather end, Model model) {
        if (select.selectWeather(start, end).isEmpty()) return "fail";
        else {
            model.addAttribute("entity", select.selectWeather(start, end));
            return "successSelect";
        }
    }
}
