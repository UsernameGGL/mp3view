package dao;

import entity.WeatherEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import javax.transaction.Transactional;
import java.util.List;

/** 处理weather与数据库交互的dao类
 */
@Transactional
public class WeatherDao extends HibernateDaoSupport{
    @Autowired
    private SessionFactory sessionFactory;

    /** 将entity中对应的数据插入数据库。
     *  若成功则返回true，否则返回false
     * @param entity
     * @return
     */
    public boolean insertInTable (WeatherEntity entity) {
        try {
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();
            session.save(entity);
            transaction.commit();
            session.close();

            return true;
        }catch (Exception e){
            System.err.println(e.getMessage());
            return false;
        }
    }

    /** 将数据库中与entity日期相同的数据记录删除。
     *  若成功则返回true，否则返回false
     * @param entity
     * @return
     */
    public boolean deleteByDate (WeatherEntity entity) {
        try {
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();
            session.delete(entity);
            transaction.commit();
            session.close();

            return true;
        }catch (Exception e){
            System.err.println(e.getMessage());
            return false;
        }
    }

    /** 将数据库中与entity日期相同的记录中数据修改为entity。
     *  若成功则返回true，否则返回false
     * @param entity
     * @return
     */
    public boolean updateWeather (WeatherEntity entity) {
        try {
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();
            session.update(entity);
            transaction.commit();
            session.close();

            return true;
        }catch (Exception e){
            System.err.println(e.getMessage());
            return false;
        }
    }

    public List<WeatherEntity> selectByDateRange (WeatherEntity start, WeatherEntity end) {
        List<WeatherEntity> findList = null;
        String hql = "select time,weather,humidity,mintemp,maxtemp from WeatherEntity ";
        if (start!=null && end!=null) {
            hql += "where time between "+start.getTime().toString();
            hql += " and "+end.getTime().toString();
        }

        try {
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();
            findList = session.createQuery(hql).list();
            transaction.commit();
            session.close();

            return findList;
        }catch (Exception e){
            System.err.println(e.getMessage());
            return findList;
        }
    }

}
