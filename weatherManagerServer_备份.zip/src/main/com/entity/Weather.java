package entity;

import java.util.Date;

/** 用于与UI层进行交互的Weather。
 */
public class Weather {
    private Date time;
    private int weather;
    private int humidity;
    private Temperature mintemp;
    private Temperature maxtemp;

    /** 无参数的构造方法。*/
    public Weather(){
        time = new Date();
        weather = 0;
        humidity = 0;
        mintemp = new Temperature();
        maxtemp = new Temperature();
    }

    /** 利用WeatherEntity的实例来创建Weather实例。
     * @param entity
     */
    public Weather(WeatherEntity entity) {
        time = entity.getTime();
        weather = entity.getWeather();
        humidity = entity.getHumidity();
        mintemp.setTemperature(convertToInt(entity.getMintemp()));
        maxtemp.setTemperature(convertToInt(entity.getMaxtemp()));
    }

    /** 将WeatherEntity中表示温度的字符串转换成int型数组。
     * @param str
     * @return
     */
    private int[] convertToInt(String str){
        int[] intArray = new int[12];
        for(int i=0;i<12;i++)
            intArray[i] = Integer.parseInt(str.substring(i*3, (i+1)*3));
        return intArray;
    }

    /** 将int型数组转换成WeatherEntity中表示温度的字符串转。
     * @param array
     * @return
     */
    private String convertToString(int[] array) {
        String str = "";
        for (int i = 0; i < array.length; i++) {
            if (array[i] < 0) str += "-"+String.format("%02",array[i]);
            else str += String.format("%03",array[i]);
        }

        return str;
    }

    public WeatherEntity convertToWeatherEntity() {
        WeatherEntity entity = new WeatherEntity();

        entity.setTime(time);
        entity.setWeather(weather);
        entity.setHumidity(humidity);
        entity.setMintemp(convertToString(mintemp.getTemperature()));
        entity.setMaxtemp(convertToString(maxtemp.getTemperature()));

        return entity;
    }


    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public int getWeather() {
        return weather;
    }

    public void setWeather(int weather) {
        this.weather = weather;
    }

    public int getHumidity() {
        return humidity;
    }

    public void setHumidity(int humidity) {
        this.humidity = humidity;
    }

    public Temperature getMintemp() {
        return mintemp;
    }

    public void setMintemp(Temperature mintemp) {
        this.mintemp = mintemp;
    }

    public Temperature getMaxtemp() {
        return maxtemp;
    }

    public void setMaxtemp(Temperature maxtemp) {
        this.maxtemp = maxtemp;
    }
}
